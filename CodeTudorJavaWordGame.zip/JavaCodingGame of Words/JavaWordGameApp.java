//* @author Tudor George Pascu
//* student number: x19209690

import java.util.Scanner;

public class JavaWordGameApp {
boolean exit;

     // call main menu class
    public static void main(String[] args) {
        new JavaWordGameMenu().funcionalMenu();
    }
}